//! [0]
bool myEventFilter(void *message);
//! [0]
